import java.util.ArrayList;
/**
 * Diese Klasse repräsentiert ein Spielfeld. Ihr Konstruktor bekommt dieses als
 * String-Array übergeben.
 */
class Field
{
    private final String[] feld;
    
    /**
    * Erstellt ein neues Spielfeld.
    * @param feld Die Beschreibung des Spielfelds.
    */

    public Field(final String[]feld)
    {
        this.feld = feld;
        for(int b=0; b<feld.length; b += 2) {
            for (int a =0; a< feld[b].length(); a+=2 ){
                //Das hier konnte ich nicht
            }
        }
    }
    /**
    *Die Methode liefert das Zeichen im gegebenen Koordinaten.
    *@param a ist die X Koordinate(Horizontal)
    *@param b ist die Y Koordinate(Vertikal)
    *@return ist das Zeichen,das zurückgegeben werden soll.Sind die Koordinaten außerhalb
    *vom Spielfeld,dann Leerzeichen.
    */
    

    char getCell(int a,int b){
        if(a >= 0 && a < feld[b].length() && 0 <= b && b < feld.length ) {
            return (feld[b].charAt(a));
        }
        else {
            return (' ');
        }
    }
    /**
     * Die Methode liefert Nachbarschafts Signatur vom gegebenen Koordinaten.
     * @param a ist die oben genannte X Koordinate.
     * @param b ist die oben genannte Y Koordinate.
     * @return ist berechnete Nachbarschaftssignatur.
     */

    int getNeighborhood(int a, int b){
            int signatur = 0;
            if(getCell(a+1,b) == '-'){
                signatur += 1;
            }
            if(getCell(a,b+1) == '|'){
                signatur += 2;
            }
            if(getCell(a-1,b) == '-'){
                signatur += 4;
            }
            if(getCell(a,b-1) == '|'){
                signatur += 8;
            }
            return signatur;
    }
    

    /**
     * Die Dateinamen der Bodengitterelemente, die direkt mit einer
     * Rotation 0 verwendet werden können. Der Index ergibt sich
     * aus der Summe der folgenden Zahlen:
     * 1: In Richtung 0 (+1, 0) gibt es eine Verbindung.
     * 2: In Richtung 1 (0, +1) gibt es eine Verbindung.
     * 4: In Richtung 2 (-1, 0) gibt es eine Verbindung.
     * 8: In Richtung 3 (0, -1) gibt es eine Verbindung.
     */
    private static final String[] NEIGHBORHOOD_TO_FILENAME = {
            "grass",
            "path-e-0",
            "path-e-1",
            "path-l-0",
            "path-e-2",
            "path-i-0",
            "path-l-1",
            "path-t-1",
            "path-e-3",
            "path-l-3",
            "path-i-1",
            "path-t-0",
            "path-l-2",
            "path-t-3",
            "path-t-2",
            "path-x"
        };

    /** Ein Testfall, der alle Nachbarschaften enthält. */
    static void test()
    {
        new GameObject.Canvas(5, 5, 96, 96);

        // Einkommentieren, sobald Konstruktor vorhanden
        new Field(new String[] {
        "O-O-O-O  ",
        "|   |    ",
        "O O-O-O O",
        "| | | | |",
        "O-O-O-O-O",
        "| | | | |",
        "O O-O-O O",
        "    |   |",
        "O-O-O-O-O"
        });
    }
}
