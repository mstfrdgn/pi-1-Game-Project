/**
 * Diese Klasse definiert <Zusammenfassung ergänzen>
 *
 * @author Sahan YALAP
 */
class Turner
{
    private final GameObject avatar;
    private final int maxSteps;
    private int stepsSoFar;

    Turner(final GameObject avatar, final int maxSteps, final int stepsSoFar)
    {
        this.avatar= avatar;
        this.maxSteps = maxSteps;
        this.stepsSoFar = stepsSoFar; 
    }

    void act (final GameObject player)
    {
        if (avatar.getRotation() == 0)
        {
            avatar.setLocation(avatar.getX()+1, avatar.getY());
        }
        else if (avatar.getRotation() == 1)
        {
            avatar.setLocation(avatar.getX(), avatar.getY()+1);
        }
        else if (avatar.getRotation() == 2)
        {
            avatar.setLocation(avatar.getX()-1, avatar.getY());
        }
        else if (avatar.getRotation() == 3)
        {
            avatar.setLocation(avatar.getX(), avatar.getY()-1);
        }

        avatar.playSound("step");

        ++stepsSoFar;

        if (stepsSoFar == maxSteps) 
        {
            avatar.setRotation(avatar.getRotation() + 2);
            stepsSoFar = 0;
        }

        if (avatar.getX() == player.getX() && avatar.getY() == player.getY())
        {
            player.setVisible(false);
            avatar.playSound("game-over");
        }

    }
}

