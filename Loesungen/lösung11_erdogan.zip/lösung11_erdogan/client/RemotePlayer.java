// Importieren der VK_*-Tastenkonstanten
import static java.awt.event.KeyEvent.*;
import java.net.*;
import java.io.*;

/**
 * Dies ist die Hauptklasse eines Spiels. Sie enthält die Hauptmethode, die zum
 * Starten des Spiels aufgerufen werden muss.
 *
 * @author Mustafa Erdogan
 */
class RemotePlayer extends Player
{
    private Socket socket1 = null;
    private DataOutputStream dataoutputstream = null;
    private OutputStream outputstream = null;
    RemotePlayer(final int x, final int y, final int rotation, final Field field)
    throws IOException
    {
        super(x, y, rotation, field);
        socket1 = new Socket("localhost", 7777);
        outputstream = socket1.getOutputStream();
        dataoutputstream = new DataOutputStream(outputstream);
    }
    
    @Override
    void act()
    {
        try{
            int key = getNextKey();
            if (key == VK_RIGHT && canWalk(0)){
                setRotation(0);
                setLocation(getX() + 1, getY());
                dataoutputstream.write(0);
                dataoutputstream.flush();
            }
            else if (key == VK_DOWN && canWalk(1)){
                setRotation(1);
                setLocation(getX(), getY() + 1);
                dataoutputstream.write(1);
                dataoutputstream.flush();
            }
            else if (key == VK_LEFT && canWalk(2)){
                setRotation(2);
                setLocation(getX() - 1, getY());
                dataoutputstream.write(2);
                dataoutputstream.flush();
            }
            else if (key == VK_UP && canWalk(3)){
                setRotation(3);
                setLocation(getX(), getY() - 1);
                dataoutputstream.write(3);
                dataoutputstream.flush();
            }
        }
        catch(IOException ioexception){
            System.out.println("Beim Lesen ist ein Fehler aufgetreten");
        }
    }
    
    @Override
    public void setVisible(final boolean visible)
    {
        super.setVisible(visible);
        try{
            if(!visible){
                socket1.close();
                outputstream.close();
                dataoutputstream.close();
            }
        }
        catch(IOException ioexception){
            System.out.println("Beim Lesen ist ein Fehler aufgetreten");
        }
    }
}
