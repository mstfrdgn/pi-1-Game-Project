// Importieren der VK_*-Tastenkonstanten
import static java.awt.event.KeyEvent.*;
import java.net.*;
import java.io.*;

/**
 * Dies ist die Hauptklasse eines Spiels. Sie enthält die Hauptmethode, die zum
 * Starten des Spiels aufgerufen werden muss.
 *
 * @author Mustafa Erdogan
 */
class ControlledPlayer extends Player
{
    private ServerSocket serversocket = null;
    private Socket socket = null;
    private InputStream inputstream = null;
    private DataInputStream datainputstream = null;
    ControlledPlayer(final int x, final int y, final int rotation, final Field field) 
    throws IOException
    {
        super(x,y,rotation,field);
        serversocket = new ServerSocket(7777);
        socket = serversocket.accept();
        inputstream = socket.getInputStream();
        datainputstream = new DataInputStream(inputstream);
    }
    
    @Override
    void act()
    {
        try{
            int key = datainputstream.read();
            if (key == 0 && canWalk(0)){
                setRotation(0);
                setLocation(getX() + 1, getY());
            }
            else if (key == 1 && canWalk(1)){
                setRotation(1);
                setLocation(getX(), getY() + 1);
            }
            else if (key == 2 && canWalk(2)){
                setRotation(2);
                setLocation(getX() - 1, getY());
            }
            else if (key == 3 && canWalk(3)){
                setRotation(3);
                setLocation(getX(), getY() - 1);
            }
            else{
                playSound("error");
            }
        }
        catch(IOException ioexception){
            System.out.println("Beim Lesen ist ein Fehler aufgetreten");
        }
    }
    
    @Override
    public void setVisible(final boolean visible)
    {
        super.setVisible(visible);
        try{
            if(!visible){
                serversocket.close();
                socket.close();
                inputstream.close();
                datainputstream.close();
            }
        }
        catch(IOException ioexception){
            System.out.println("Beim Lesen ist ein Fehler aufgetreten");
        }
    }
}
