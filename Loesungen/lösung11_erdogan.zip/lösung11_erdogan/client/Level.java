import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
/**
 * @author Mustafa Erdogan
 */
public class Level {
    private ArrayList<GameObject> akteureList = new ArrayList<>();
    private Field field;
    private Player player;
    Level(String fieldText, boolean remote){
        try {
            FileInputStream fis = new FileInputStream(fieldText + ".txt");
            ArrayList<String> mapList = new ArrayList<>();
            int value;
            String convert = "";
            int count = 0;
            while(true){
                value = fis.read();
                if(value == -1){
                    break;
                }
                convert += (char)value;
                count++;
                if(count == 9){
                    mapList.add(convert);
                    convert = "";
                    count = 0;
                }
            }
            String[] map = new String[mapList.size()];
            for(int i = 0 ; i < mapList.size(); i++){
                map[i] = mapList.get(i);
            }
            field = new Field(map);
            akteureList.add(new GameObject(11,11,0,"laila"));
            if(remote){
                player = new RemotePlayer
                (akteureList.get(0).getX(),
                    akteureList.get(0).getY(),
                    akteureList.get(0).getRotation(),field);
            }
            else {
                player = new ControlledPlayer
                (akteureList.get(0).getX(),
                    akteureList.get(0).getY(),
                    akteureList.get(0).getRotation(),field);
            }
            akteureList.get(0).setVisible(false);
            int counter = 0;
            /*Laila p-0,q-1, P-2, Q-3
             *Woman r-0, s-1, R-2, S-3
             *Claudius t-0, u-1, T-2, U-3
             *Child v-0, w-1, V-2, W-3
             */
            for(int y = 0 ; y < map.length; y++){
                for(int x = 0; x < map[y].length() ; x++){
                    if(map[y].charAt(x) == 'p'){
                        akteureList.get(0).setLocation(x/2,y/2);
                        akteureList.get(0).setRotation(0);
                        player.setLocation(x/2,y/2);
                        player.setRotation(0);
                        counter++;
                    }
                    else if(map[y].charAt(x) == 'q'){
                        akteureList.get(0).setLocation(x/2,y/2);
                        akteureList.get(0).setRotation(1);
                        player.setLocation(x/2,y/2);
                        player.setRotation(1);
                        counter++;
                    }
                    else if(map[y].charAt(x) == 'P'){
                        akteureList.get(0).setLocation(x/2,y/2);
                        akteureList.get(0).setRotation(2);
                        player.setLocation(x/2,y/2);
                        player.setRotation(2);
                        counter++;
                    }
                    else if(map[y].charAt(x) == 'Q'){
                        akteureList.get(0).setLocation(x/2,y/2);
                        akteureList.get(0).setRotation(3);
                        player.setLocation(x/2,y/2);
                        player.setRotation(3);
                        counter++;
                    }
                    else if(map[y].charAt(x) == 'r'){
                        akteureList.add(new GameObject(x/2,y/2,0,"woman"));
                    }
                    else if(map[y].charAt(x) == 's'){
                        akteureList.add(new GameObject(x/2,y/2,1,"woman"));
                    }
                    else if(map[y].charAt(x) == 'R'){
                        akteureList.add(new GameObject(x/2,y/2,2,"woman"));
                    }
                    else if(map[y].charAt(x) == 'S'){
                        akteureList.add(new GameObject(x/2,y/2,3,"woman"));
                    }
                    else if(map[y].charAt(x) == 't'){
                        akteureList.add(new GameObject(x/2,y/2,0,"claudius"));
                    }
                    else if(map[y].charAt(x) == 'u'){
                        akteureList.add(new GameObject(x/2,y/2,1,"claudius"));
                    }
                    else if(map[y].charAt(x) == 'T'){
                        akteureList.add(new GameObject(x/2,y/2,2,"claudius"));
                    }
                    else if(map[y].charAt(x) == 'U'){
                        akteureList.add(new GameObject(x/2,y/2,3,"claudius"));
                    }
                    else if(map[y].charAt(x) == 'v'){
                        akteureList.add(new GameObject(x/2,y/2,0,"child"));
                    }
                    else if(map[y].charAt(x) == 'w'){
                        akteureList.add(new GameObject(x/2,y/2,1,"child"));
                    }
                    else if(map[y].charAt(x) == 'V'){
                        akteureList.add(new GameObject(x/2,y/2,2,"child"));
                    }
                    else if(map[y].charAt(x) == 'W'){
                        akteureList.add(new GameObject(x/2,y/2,3,"child"));
                    }
                    else if(map[y].charAt(x) != ' '
                    && map[y].charAt(x) != '-'
                    && map[y].charAt(x) != 'O'
                    && map[y].charAt(x) != '|'){
                        throw new IllegalArgumentException
                        ("Die Datei enthält ungültige Symbole an den Positionen von Gitterknoten.");
                    }
                }
            }
            if(akteureList.get(0).getX() == 10 || counter >= 2){
                throw new IllegalArgumentException("Die Datei enthält nicht genau einen Player.");
            }
        } catch (FileNotFoundException ex) {
            throw new IllegalArgumentException("Die Level-Datei wurde nicht gefunden.");
        } catch (IOException ex) {
            throw new IllegalArgumentException("Beim Lesen ist ein Fehler aufgetreten");
        }
    }

    ArrayList<GameObject> getList(){
        return akteureList;
    }

    Field getField(){
        return field;
    }

    Player getPlayer(){
        return player;
    }

    void hide(){
        player.setVisible(false);
        for(GameObject gameobject : akteureList){
            gameobject.setVisible(false);
        }

    }

        
        
}
